
package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class NewItems extends JFrame {

    private final Color black = new Color(25, 18, 16);
    private final Color burgundy = new Color(85, 25, 35);
    private final Color gold = new Color(212, 175, 95);
    private final Color cream = new Color(245, 235, 211);
    private final Color white = new Color(255, 253, 248);

    private JTextField nameField;
    private JTextField categoryField;
    private JTextField sizeField;
    private JTextField priceField;
    private JTextField quantityField;
    private JComboBox<String> conditionBox;
    private DefaultTableModel tableModel;

    public NewItems() {
        setTitle("POLO APPAREL | Add New Item");
        setSize(1000, 700);
        setMinimumSize(new Dimension(850, 600));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(cream);

        // HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(black);
        header.setBorder(BorderFactory.createEmptyBorder(18, 25, 18, 25));

        JLabel title = new JLabel("POLO APPAREL");
        title.setFont(new Font("Georgia", Font.BOLD, 26));
        title.setForeground(gold);

        JLabel subtitle = new JLabel("ADD NEW ITEM");
        subtitle.setFont(new Font("Arial", Font.BOLD, 12));
        subtitle.setForeground(cream);

        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.setBackground(black);
        titlePanel.add(title);
        titlePanel.add(Box.createVerticalStrut(5));
        titlePanel.add(subtitle);

        JButton backButton = new JButton("BACK TO DASHBOARD");
        backButton.setFont(new Font("Arial", Font.BOLD, 11));
        backButton.setBackground(burgundy);
        backButton.setForeground(white);
        backButton.setFocusPainted(false);
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        header.add(titlePanel, BorderLayout.WEST);
        header.add(backButton, BorderLayout.EAST);

        // FORM
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(white);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 205, 180)),
                BorderFactory.createEmptyBorder(20, 25, 20, 25)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        nameField = new JTextField(18);
        categoryField = new JTextField(18);
        sizeField = new JTextField(18);
        priceField = new JTextField(18);
        quantityField = new JTextField("1", 18);

        conditionBox = new JComboBox<>(new String[]{
            "Pre-Owned", "Like New", "Brand New"
        });

        styleField(nameField);
        styleField(categoryField);
        styleField(sizeField);
        styleField(priceField);
        styleField(quantityField);

        conditionBox.setFont(new Font("Arial", Font.PLAIN, 13));
        conditionBox.setBackground(white);

        addFormRow(formPanel, gbc, 0, "Item Name:", nameField);
        addFormRow(formPanel, gbc, 1, "Category:", categoryField);
        addFormRow(formPanel, gbc, 2, "Size:", sizeField);
        addFormRow(formPanel, gbc, 3, "Price (₱):", priceField);
        addFormRow(formPanel, gbc, 4, "Quantity:", quantityField);
        addFormRow(formPanel, gbc, 5, "Condition:", conditionBox);

        JButton saveButton = new JButton("SAVE NEW ITEM");
        saveButton.setFont(new Font("Arial", Font.BOLD, 12));
        saveButton.setBackground(burgundy);
        saveButton.setForeground(white);
        saveButton.setFocusPainted(false);
        saveButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JButton clearButton = new JButton("CLEAR FORM");
        clearButton.setFont(new Font("Arial", Font.BOLD, 12));
        clearButton.setBackground(cream);
        clearButton.setForeground(black);
        clearButton.setFocusPainted(false);
        clearButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(white);
        buttonPanel.add(clearButton);
        buttonPanel.add(saveButton);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        formPanel.add(buttonPanel, gbc);

        // RECENT ITEMS TABLE
        String[] columns = {
            "ID", "Item Name", "Category", "Size",
            "Price", "Quantity", "Condition", "Status"
        };

        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable itemsTable = new JTable(tableModel);
        itemsTable.setRowHeight(28);
        itemsTable.setFont(new Font("Arial", Font.PLAIN, 12));
        itemsTable.setBackground(white);
        itemsTable.setForeground(black);
        itemsTable.setGridColor(new Color(230, 220, 205));
        itemsTable.getTableHeader().setFont(
                new Font("Arial", Font.BOLD, 11)
        );
        itemsTable.getTableHeader().setBackground(burgundy);
        itemsTable.getTableHeader().setForeground(white);

        JScrollPane tableScroll = new JScrollPane(itemsTable);
        tableScroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(220, 205, 180)),
                "RECENTLY ADDED ITEMS"
        ));

        JPanel centerPanel = new JPanel(new BorderLayout(15, 15));
        centerPanel.setBackground(cream);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        centerPanel.add(formPanel, BorderLayout.NORTH);
        centerPanel.add(tableScroll, BorderLayout.CENTER);

        JLabel footer = new JLabel("POLO APPAREL | PRE-LOVED FASHION");
        footer.setHorizontalAlignment(SwingConstants.CENTER);
        footer.setFont(new Font("Arial", Font.PLAIN, 10));
        footer.setForeground(new Color(100, 85, 75));
        footer.setBorder(BorderFactory.createEmptyBorder(8, 0, 12, 0));

        mainPanel.add(header, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(footer, BorderLayout.SOUTH);

        add(mainPanel);

        // BUTTON ACTIONS
        backButton.addActionListener(e -> {
            new AdminDashBoard().setVisible(true);
            dispose();
        });

        saveButton.addActionListener(e -> saveItem());

        clearButton.addActionListener(e -> clearForm());

        loadRecentItems();
    }

    private void addFormRow(
            JPanel panel,
            GridBagConstraints gbc,
            int row,
            String labelText,
            JComponent field) {

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.3;

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.BOLD, 12));
        label.setForeground(black);
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.7;
        panel.add(field, gbc);
    }

    private void styleField(JTextField field) {
        field.setFont(new Font("Arial", Font.PLAIN, 13));
        field.setBackground(white);
        field.setForeground(black);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 185, 160)),
                BorderFactory.createEmptyBorder(7, 8, 7, 8)
        ));
    }

    private void saveItem() {
        String name = nameField.getText().trim();
        String category = categoryField.getText().trim();
        String size = sizeField.getText().trim();
        String priceText = priceField.getText().trim();
        String quantityText = quantityField.getText().trim();
        String condition = (String) conditionBox.getSelectedItem();

        if (name.isEmpty() || category.isEmpty()
                || size.isEmpty() || priceText.isEmpty()
                || quantityText.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please fill in all item details.",
                    "Missing Information",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        BigDecimal price;
        int quantity;

        try {
            price = new BigDecimal(priceText);

            if (price.compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(
                        this, "Price must be greater than zero."
                );
                return;
            }

            quantity = Integer.parseInt(quantityText);

            if (quantity <= 0) {
                JOptionPane.showMessageDialog(
                        this, "Quantity must be greater than zero."
                );
                return;
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Enter a valid price and whole-number quantity.",
                    "Invalid Input",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        String sql = """
            INSERT INTO items
            (item_name, category, size, price, quantity,
             item_condition, date_added, status)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_DATE, 'AVAILABLE')
            """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, category);
            stmt.setString(3, size);
            stmt.setBigDecimal(4, price);
            stmt.setInt(5, quantity);
            stmt.setString(6, condition);

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Item saved successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            clearForm();
            loadRecentItems();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Unable to save item.\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void loadRecentItems() {
        tableModel.setRowCount(0);

        String sql = """
            SELECT item_id, item_name, category, size,
                   price, quantity, item_condition, status
            FROM items
            ORDER BY item_id DESC
            LIMIT 100
            """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("item_id"),
                    rs.getString("item_name"),
                    rs.getString("category"),
                    rs.getString("size"),
                    "₱" + rs.getBigDecimal("price"),
                    rs.getInt("quantity"),
                    rs.getString("item_condition"),
                    rs.getString("status")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Unable to load items.\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void clearForm() {
        nameField.setText("");
        categoryField.setText("");
        sizeField.setText("");
        priceField.setText("");
        quantityField.setText("1");
        conditionBox.setSelectedIndex(0);
        nameField.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new NewItems().setVisible(true);
        });
    }
}
