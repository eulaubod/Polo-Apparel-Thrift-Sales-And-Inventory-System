
package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.text.NumberFormat;
import java.util.Locale;

public class SoldThisWeek extends JFrame {

    private final Color BLACK = new Color(18, 18, 18);
    private final Color BURGUNDY = new Color(92, 20, 43);
    private final Color GOLD = new Color(205, 170, 95);
    private final Color CREAM = new Color(248, 244, 235);
    private final Color GRAY = new Color(225, 221, 213);

    private JTable table;
    private DefaultTableModel model;
    private JLabel totalSalesLabel;
    private JLabel itemsSoldLabel;
    private JLabel transactionsLabel;

    private final NumberFormat money =
            NumberFormat.getCurrencyInstance(new Locale("en", "PH"));

    public SoldThisWeek() {
        setTitle("POLO APPAREL | Sold This Week");
        setSize(1150, 700);
        setMinimumSize(new Dimension(950, 600));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(CREAM);
        setLayout(new BorderLayout());

        add(createHeader(), BorderLayout.NORTH);
        add(createMainPanel(), BorderLayout.CENTER);

        loadSoldItems();
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BLACK);
        header.setBorder(BorderFactory.createEmptyBorder(22, 30, 22, 30));

        JPanel brandPanel = new JPanel();
        brandPanel.setLayout(new BoxLayout(brandPanel, BoxLayout.Y_AXIS));
        brandPanel.setOpaque(false);

        JLabel brand = new JLabel("POLO APPAREL");
        brand.setFont(new Font("Serif", Font.BOLD, 27));
        brand.setForeground(GOLD);

        JLabel subtitle = new JLabel("THRIFT MANAGEMENT SYSTEM");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 11));
        subtitle.setForeground(CREAM);

        brandPanel.add(brand);
        brandPanel.add(Box.createVerticalStrut(5));
        brandPanel.add(subtitle);

      JButton backButton = new JButton("BACK");
backButton.setFont(new Font("SansSerif", Font.BOLD, 12));
backButton.setBackground(BURGUNDY);
backButton.setForeground(CREAM);
backButton.setFocusPainted(false);
backButton.setBorderPainted(false);
backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
backButton.setPreferredSize(new Dimension(130, 38));

backButton.addActionListener(e -> {
    new AdminDashBoard().setVisible(true);
    dispose();
});

header.add(brandPanel, BorderLayout.WEST);
header.add(backButton, BorderLayout.EAST);

return header;
    }

    private JPanel createMainPanel() {
        JPanel main = new JPanel(new BorderLayout(0, 20));
        main.setBackground(CREAM);
        main.setBorder(BorderFactory.createEmptyBorder(25, 30, 30, 30));

        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.setOpaque(false);

        JLabel title = new JLabel("Sold This Week");
        title.setFont(new Font("Serif", Font.BOLD, 30));
        title.setForeground(BLACK);

        JLabel description = new JLabel(
                "A summary of completed sales from Monday to Sunday.");
        description.setFont(new Font("SansSerif", Font.PLAIN, 13));
        description.setForeground(new Color(100, 95, 88));

        titlePanel.add(title);
        titlePanel.add(Box.createVerticalStrut(7));
        titlePanel.add(description);
        titlePanel.add(Box.createVerticalStrut(20));
        titlePanel.add(createSummaryCards());

        JPanel tablePanel = new JPanel(new BorderLayout(0, 12));
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(GRAY),
                BorderFactory.createEmptyBorder(18, 18, 18, 18)));

        JLabel tableTitle = new JLabel("WEEKLY SALES RECORD");
        tableTitle.setFont(new Font("SansSerif", Font.BOLD, 14));
        tableTitle.setForeground(BURGUNDY);

        model = new DefaultTableModel(
                new String[]{
                    "Transaction ID", "Customer", "Item Name",
                    "Quantity", "Selling Price", "Total Amount", "Date Sold"
                }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setFont(new Font("SansSerif", Font.PLAIN, 12));
        table.setRowHeight(32);
        table.setBackground(Color.WHITE);
        table.setForeground(BLACK);
        table.setSelectionBackground(new Color(238, 225, 194));
        table.setSelectionForeground(BLACK);
        table.setGridColor(GRAY);
        table.setShowVerticalLines(false);
        table.getTableHeader().setFont(
                new Font("SansSerif", Font.BOLD, 11));
        table.getTableHeader().setBackground(BLACK);
        table.getTableHeader().setForeground(GOLD);
        table.getTableHeader().setPreferredSize(new Dimension(0, 38));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        tablePanel.add(tableTitle, BorderLayout.NORTH);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        main.add(titlePanel, BorderLayout.NORTH);
        main.add(tablePanel, BorderLayout.CENTER);

        return main;
    }

    private JPanel createSummaryCards() {
        JPanel cards = new JPanel(new GridLayout(1, 3, 15, 0));
        cards.setOpaque(false);

        totalSalesLabel = new JLabel("₱0.00");
        itemsSoldLabel = new JLabel("0");
        transactionsLabel = new JLabel("0");

        cards.add(createCard("TOTAL SALES THIS WEEK", totalSalesLabel));
        cards.add(createCard("TOTAL ITEMS SOLD", itemsSoldLabel));
        cards.add(createCard("TRANSACTIONS", transactionsLabel));

        return cards;
    }

    private JPanel createCard(String title, JLabel valueLabel) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(GRAY),
                BorderFactory.createEmptyBorder(17, 18, 17, 18)));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 11));
        titleLabel.setForeground(new Color(100, 95, 88));

        valueLabel.setFont(new Font("Serif", Font.BOLD, 25));
        valueLabel.setForeground(BURGUNDY);

        card.add(titleLabel);
        card.add(Box.createVerticalStrut(12));
        card.add(valueLabel);

        return card;
    }

    private void loadSoldItems() {
        model.setRowCount(0);

        String sql =
                "SELECT t.transaction_id, t.customer_name, i.item_name, " +
                "t.quantity_sold, t.sold_price, t.total_amount, " +
                "t.transaction_date " +
                "FROM transactions t " +
                "JOIN items i ON t.item_id = i.item_id " +
                "WHERE YEARWEEK(t.transaction_date, 1) = " +
                "YEARWEEK(CURDATE(), 1) " +
                "ORDER BY t.transaction_date DESC";

        double totalSales = 0;
        int totalItems = 0;
        int totalTransactions = 0;

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int quantity = rs.getInt("quantity_sold");
                double amount = rs.getDouble("total_amount");
                Timestamp date = rs.getTimestamp("transaction_date");

                model.addRow(new Object[]{
                    rs.getInt("transaction_id"),
                    rs.getString("customer_name"),
                    rs.getString("item_name"),
                    quantity,
                    money.format(rs.getBigDecimal("sold_price")),
                    money.format(rs.getBigDecimal("total_amount")),
                    date == null ? "" : date.toLocalDateTime()
                            .toString().replace('T', ' ')
                });

                totalSales += amount;
                totalItems += quantity;
                totalTransactions++;
            }

            totalSalesLabel.setText(money.format(totalSales));
            itemsSoldLabel.setText(String.valueOf(totalItems));
            transactionsLabel.setText(String.valueOf(totalTransactions));

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Could not load weekly sales.\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
                new SoldThisWeek().setVisible(true));
    }
}
