
package gui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StoreData {

    public static List<Object[]> availableItems = new ArrayList<>();
    public static List<Object[]> soldItems = new ArrayList<>();
    public static List<Object[]> newItems = new ArrayList<>();
    public static List<Object[]> transactions = new ArrayList<>();

    public static void loadItems() {
        availableItems.clear();
        soldItems.clear();
        newItems.clear();

        String sql = "SELECT item_id, item_name, category, size, price, "
                + "quantity, item_condition, date_added, status FROM items";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Object[] item = {
                    rs.getInt("item_id"),
                    rs.getString("item_name"),
                    rs.getString("category"),
                    rs.getString("size"),
                    rs.getDouble("price"),
                    rs.getInt("quantity"),
                    rs.getString("item_condition"),
                    rs.getDate("date_added"),
                    rs.getString("status")
                };

                if ("SOLD".equals(rs.getString("status"))) {
                    soldItems.add(item);
                } else {
                    availableItems.add(item);
                }
            }

        } catch (SQLException e) {
            System.err.println("Loading items failed: " + e.getMessage());
        }
    }

    public static boolean addItem(
            String itemName,
            String category,
            String size,
            double price,
            int quantity,
            String condition) {

        String sql = "INSERT INTO items "
                + "(item_name, category, size, price, quantity, "
                + "item_condition, date_added, status) "
                + "VALUES (?, ?, ?, ?, ?, ?, CURRENT_DATE, 'AVAILABLE')";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, itemName);
            ps.setString(2, category);
            ps.setString(3, size);
            ps.setDouble(4, price);
            ps.setInt(5, quantity);
            ps.setString(6, condition);

            ps.executeUpdate();
            loadItems();
            return true;

        } catch (SQLException e) {
            System.err.println("Adding item failed: " + e.getMessage());
            return false;
        }
    }

    public static boolean markAsSold(int itemId, String customerName) {
        String selectSql = "SELECT price, quantity FROM items "
                + "WHERE item_id = ? AND status = 'AVAILABLE'";

        try (Connection con = DatabaseConnection.getConnection()) {
            con.setAutoCommit(false);

            try {
                double price;
                int quantity;

                try (PreparedStatement ps =
                        con.prepareStatement(selectSql)) {
                    ps.setInt(1, itemId);

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            con.rollback();
                            return false;
                        }

                        price = rs.getDouble("price");
                        quantity = rs.getInt("quantity");
                    }
                }

                if (quantity <= 0) {
                    con.rollback();
                    return false;
                }

                String updateSql = "UPDATE items "
                        + "SET quantity = 0, status = 'SOLD' "
                        + "WHERE item_id = ?";

                try (PreparedStatement ps =
                        con.prepareStatement(updateSql)) {
                    ps.setInt(1, itemId);
                    ps.executeUpdate();
                }

                String insertSql = "INSERT INTO transactions "
                        + "(customer_name, item_id, quantity_sold, "
                        + "sold_price, total_amount, transaction_date) "
                        + "VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";

                try (PreparedStatement ps =
                        con.prepareStatement(insertSql)) {
                    ps.setString(1, customerName);
                    ps.setInt(2, itemId);
                    ps.setInt(3, quantity);
                    ps.setDouble(4, price);
                    ps.setDouble(5, price * quantity);
                    ps.executeUpdate();
                }

                con.commit();
                loadItems();
                loadTransactions();
                return true;

            } catch (SQLException e) {
                con.rollback();
                System.err.println("Sale failed: " + e.getMessage());
                return false;
            } finally {
                con.setAutoCommit(true);
            }

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            return false;
        }
    }

    public static void loadTransactions() {
        transactions.clear();

        String sql = "SELECT t.transaction_id, t.customer_name, "
                + "i.item_name, t.quantity_sold, t.sold_price, "
                + "t.total_amount, t.transaction_date "
                + "FROM transactions t JOIN items i "
                + "ON t.item_id = i.item_id "
                + "ORDER BY t.transaction_date DESC";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                transactions.add(new Object[]{
                    rs.getInt("transaction_id"),
                    rs.getString("customer_name"),
                    rs.getString("item_name"),
                    rs.getInt("quantity_sold"),
                    rs.getDouble("sold_price"),
                    rs.getDouble("total_amount"),
                    rs.getTimestamp("transaction_date")
                });
            }

        } catch (SQLException e) {
            System.err.println("Loading transactions failed: "
                    + e.getMessage());
        }
    }

    public static double getWeeklyIncome() {
        String sql = "SELECT COALESCE(SUM(total_amount), 0) "
                + "FROM transactions "
                + "WHERE transaction_date >= "
                + "CURRENT_DATE - INTERVAL 6 DAY";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getDouble(1);
            }

        } catch (SQLException e) {
            System.err.println("Income error: " + e.getMessage());
        }

        return 0.0;
    }
}
