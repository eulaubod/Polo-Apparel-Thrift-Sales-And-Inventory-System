
package gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class AdminLogin extends JFrame {

    private final Color black = new Color(17, 17, 17);
    private final Color burgundy = new Color(91, 15, 35);
    private final Color gold = new Color(207, 169, 97);
    private final Color cream = new Color(246, 239, 224);
    private final Color muted = new Color(165, 165, 165);

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private int failedAttempts = 0;

    private final int MAX_ATTEMPTS = 5;

    public AdminLogin() {
        setTitle("POLO APPAREL | Admin Login");
        setSize(1000, 650);
        setMinimumSize(new Dimension(850, 550));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new GridLayout(1, 2));
        root.setBackground(black);
        setContentPane(root);

        // LEFT PANEL
        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setBackground(burgundy);
        left.setBorder(new EmptyBorder(65, 45, 45, 35));

        JLabel brand = new JLabel("POLO APPAREL");
        brand.setFont(new Font("Serif", Font.BOLD, 30));
        brand.setForeground(gold);

        JLabel heading = new JLabel("<html>Welcome<br>Back.</html>");
        heading.setFont(new Font("Serif", Font.BOLD, 43));
        heading.setForeground(cream);

        JLabel description = new JLabel(
            "<html>Manage your store with confidence.<br>"
            + "Your inventory and sales records<br>"
            + "are just one login away.</html>"
        );
        description.setFont(new Font("SansSerif", Font.PLAIN, 14));
        description.setForeground(cream);

        left.add(brand);
        left.add(Box.createVerticalStrut(75));
        left.add(heading);
        left.add(Box.createVerticalStrut(20));
        left.add(description);
        left.add(Box.createVerticalGlue());

        JLabel footer = new JLabel("CLASSIC STYLE | SMART MANAGEMENT");
        footer.setFont(new Font("SansSerif", Font.PLAIN, 10));
        footer.setForeground(gold);
        left.add(footer);

        // RIGHT PANEL
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(black);

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(black);
        form.setBorder(new EmptyBorder(30, 35, 30, 35));
        form.setPreferredSize(new Dimension(390, 440));

        JLabel title = new JLabel("Admin Login");
        title.setFont(new Font("Serif", Font.BOLD, 34));
        title.setForeground(cream);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel(
            "Enter your account details to continue."
        );
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 12));
        subtitle.setForeground(muted);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel usernameLabel = createLabel("USERNAME");
        usernameField = new JTextField();
        styleField(usernameField);

        JLabel passwordLabel = createLabel("PASSWORD");
        passwordField = new JPasswordField();
        styleField(passwordField);

        JCheckBox showPassword = new JCheckBox("Show password");
        showPassword.setBackground(black);
        showPassword.setForeground(muted);
        showPassword.setFocusPainted(false);
        showPassword.setAlignmentX(Component.LEFT_ALIGNMENT);

        showPassword.addActionListener(e ->
            passwordField.setEchoChar(
                showPassword.isSelected() ? (char) 0 : '\u2022'
            )
        );

        loginButton = new JButton("SIGN IN");
        loginButton.setFont(new Font("SansSerif", Font.BOLD, 13));
        loginButton.setForeground(cream);
        loginButton.setBackground(burgundy);
        loginButton.setFocusPainted(false);
        loginButton.setBorderPainted(false);
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginButton.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 45)
        );
        loginButton.addActionListener(e -> login());

        // Press Enter to sign in
        getRootPane().setDefaultButton(loginButton);

        JButton backButton = new JButton("← Back to Welcome Page");
        backButton.setFont(new Font("SansSerif", Font.PLAIN, 12));
        backButton.setForeground(gold);
        backButton.setBackground(black);
        backButton.setBorderPainted(false);
        backButton.setFocusPainted(false);
        backButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        backButton.addActionListener(e -> {
            new WelcomePage().setVisible(true);
            dispose();
        });

        form.add(title);
        form.add(Box.createVerticalStrut(10));
        form.add(subtitle);
        form.add(Box.createVerticalStrut(35));
        form.add(usernameLabel);
        form.add(Box.createVerticalStrut(8));
        form.add(usernameField);
        form.add(Box.createVerticalStrut(20));
        form.add(passwordLabel);
        form.add(Box.createVerticalStrut(8));
        form.add(passwordField);
        form.add(Box.createVerticalStrut(10));
        form.add(showPassword);
        form.add(Box.createVerticalStrut(25));
        form.add(loginButton);
        form.add(Box.createVerticalStrut(15));
        form.add(backButton);

        right.add(form);

        root.add(left);
        root.add(right);
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("SansSerif", Font.BOLD, 11));
        label.setForeground(gold);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private void styleField(JTextField field) {
        field.setFont(new Font("SansSerif", Font.PLAIN, 14));
        field.setForeground(cream);
        field.setBackground(new Color(30, 30, 30));
        field.setCaretColor(gold);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(75, 75, 75)),
            new EmptyBorder(10, 12, 10, 12)
        ));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    // LOGIN VALIDATION
    private void login() {

        if (failedAttempts >= MAX_ATTEMPTS) {
            JOptionPane.showMessageDialog(
                this,
                "Login is locked. Please restart the application.",
                "Login Locked",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        // Validate username
        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Please enter your username.",
                "Username Required",
                JOptionPane.WARNING_MESSAGE
            );
            usernameField.requestFocusInWindow();
            return;
        }

        // Validate password
        if (password.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Please enter your password.",
                "Password Required",
                JOptionPane.WARNING_MESSAGE
            );
            passwordField.requestFocusInWindow();
            return;
        }

        // Check credentials
        if (username.equals("admin") && password.equals("admin")) {

            JOptionPane.showMessageDialog(
                this,
                "Login successful. Welcome to POLO APPAREL!",
                "Login Successful",
                JOptionPane.INFORMATION_MESSAGE
            );

            new AdminDashBoard().setVisible(true);
            dispose();

        } else {
            failedAttempts++;

            // Clear password after failed login
            passwordField.setText("");

            if (failedAttempts >= MAX_ATTEMPTS) {

                loginButton.setEnabled(false);
                usernameField.setEnabled(false);
                passwordField.setEnabled(false);

                JOptionPane.showMessageDialog(
                    this,
                    "You have entered incorrect details 5 times.\n"
                    + "Login is now locked.",
                    "Login Locked",
                    JOptionPane.ERROR_MESSAGE
                );

            } else {
                int remaining = MAX_ATTEMPTS - failedAttempts;

                JOptionPane.showMessageDialog(
                    this,
                    "Incorrect username or password.\n"
                    + "Attempts remaining: " + remaining,
                    "Login Failed",
                    JOptionPane.ERROR_MESSAGE
                );

                passwordField.requestFocusInWindow();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
            new AdminLogin().setVisible(true)
        );
    }
}
