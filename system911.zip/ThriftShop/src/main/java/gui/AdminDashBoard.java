
package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminDashBoard extends JFrame {

    private final Color black = new Color(25, 18, 16);
    private final Color burgundy = new Color(85, 25, 35);
    private final Color gold = new Color(212, 175, 95);
    private final Color cream = new Color(245, 235, 211);
    private final Color white = new Color(255, 253, 248);

    public AdminDashBoard() {
        setTitle("POLO APPAREL THRIFT MANAGEMENT");
        setSize(1200, 750);
        setMinimumSize(new Dimension(1000, 650));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(cream);

        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(230, 750));
        sidebar.setBackground(black);
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBorder(BorderFactory.createEmptyBorder(30, 15, 20, 15));

        JLabel brand = new JLabel("POLO APPAREL");
        brand.setFont(new Font("Georgia", Font.BOLD, 22));
        brand.setForeground(gold);
        brand.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("THRIFT MANAGEMENT");
        subtitle.setFont(new Font("Arial", Font.PLAIN, 10));
        subtitle.setForeground(cream);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        sidebar.add(brand);
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(subtitle);
        sidebar.add(Box.createVerticalStrut(30));

        JButton btnBack = createButton("BACK");
        JButton btnDashboard = createButton("DASHBOARD");
        JButton btnAdd = createButton("ADD ITEM");
        JButton btnAvailable = createButton("AVAILABLE ITEMS");
        JButton btnNew = createButton("NEW ITEMS");
        JButton btnSold = createButton("SOLD THIS WEEK");
        JButton btnTransactions = createButton("TRANSACTION HISTORY");
        JButton btnLogout = createButton("LOG OUT");

        sidebar.add(btnBack);
        sidebar.add(Box.createVerticalStrut(12));
        sidebar.add(btnDashboard);
        sidebar.add(Box.createVerticalStrut(12));
        sidebar.add(btnAdd);
        sidebar.add(Box.createVerticalStrut(12));
        sidebar.add(btnAvailable);
        sidebar.add(Box.createVerticalStrut(12));
        sidebar.add(btnNew);
        sidebar.add(Box.createVerticalStrut(12));
        sidebar.add(btnSold);
        sidebar.add(Box.createVerticalStrut(12));
        sidebar.add(btnTransactions);
        sidebar.add(Box.createVerticalGlue());
        sidebar.add(btnLogout);

        JPanel content = new JPanel(new BorderLayout(15, 15));
        content.setBackground(cream);
        content.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(cream);

        JPanel headingText = new JPanel();
        headingText.setLayout(new BoxLayout(headingText, BoxLayout.Y_AXIS));
        headingText.setBackground(cream);

        JLabel dashboardTitle = new JLabel("POLO APPAREL THRIFT MANAGEMENT");
        dashboardTitle.setFont(new Font("Georgia", Font.BOLD, 25));
        dashboardTitle.setForeground(black);

        JLabel welcomeText = new JLabel(
                "Welcome, Admin! Here's your store overview."
        );
        welcomeText.setFont(new Font("Arial", Font.PLAIN, 13));
        welcomeText.setForeground(new Color(100, 85, 75));

        headingText.add(dashboardTitle);
        headingText.add(Box.createVerticalStrut(8));
        headingText.add(welcomeText);

        JLabel dateLabel = new JLabel("STORE ADMIN");
        dateLabel.setFont(new Font("Arial", Font.BOLD, 12));
        dateLabel.setForeground(burgundy);

        header.add(headingText, BorderLayout.WEST);
        header.add(dateLabel, BorderLayout.EAST);

        JPanel cards = new JPanel(new GridLayout(1, 3, 15, 0));
        cards.setBackground(cream);
        cards.setPreferredSize(new Dimension(800, 125));

        cards.add(createCard(
                "AVAILABLE ITEMS", "42", "Items ready for sale"
        ));
        cards.add(createCard(
                "NEW ITEMS", "5", "Recently added items"
        ));
        cards.add(createCard(
                "SOLD THIS WEEK", "18", "Items sold this week"
        ));

        JPanel transactionPanel = new JPanel(new BorderLayout(10, 12));
        transactionPanel.setBackground(white);
        transactionPanel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(220, 205, 180)
                        ),
                        BorderFactory.createEmptyBorder(18, 18, 18, 18)
                )
        );

        JPanel transactionHeader = new JPanel(new BorderLayout());
        transactionHeader.setBackground(white);

        JLabel transactionTitle = new JLabel("RECENT TRANSACTIONS");
        transactionTitle.setFont(new Font("Georgia", Font.BOLD, 19));
        transactionTitle.setForeground(black);

        JButton viewAllButton = new JButton("VIEW ALL");
        viewAllButton.setBackground(burgundy);
        viewAllButton.setForeground(white);
        viewAllButton.setFocusPainted(false);
        viewAllButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        transactionHeader.add(transactionTitle, BorderLayout.WEST);
        transactionHeader.add(viewAllButton, BorderLayout.EAST);

        String[] columns = {
            "Transaction ID",
            "Customer",
            "Item Purchased",
            "Date",
            "Amount"
        };

        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        String sql = """
            SELECT t.transaction_id, t.customer_name, i.item_name,
                   t.transaction_date, t.total_amount
            FROM transactions t
            LEFT JOIN items i ON t.item_id = i.item_id
            ORDER BY t.transaction_date DESC
            LIMIT 10
            """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    "TRX-" + rs.getInt("transaction_id"),
                    rs.getString("customer_name"),
                    rs.getString("item_name"),
                    rs.getString("transaction_date"),
                    "₱" + String.format(
                            "%.2f", rs.getDouble("total_amount")
                    )
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Could not load transactions from database.\n"
                    + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        JTable transactionTable = new JTable(model);
        transactionTable.setRowHeight(35);
        transactionTable.setFont(new Font("Arial", Font.PLAIN, 12));
        transactionTable.setForeground(black);
        transactionTable.setBackground(white);
        transactionTable.setSelectionBackground(new Color(235, 220, 195));
        transactionTable.setGridColor(new Color(230, 220, 205));
        transactionTable.getTableHeader().setFont(
                new Font("Arial", Font.BOLD, 12)
        );
        transactionTable.getTableHeader().setBackground(burgundy);
        transactionTable.getTableHeader().setForeground(white);
        transactionTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        JScrollPane scrollPane = new JScrollPane(transactionTable);
        scrollPane.getViewport().setBackground(white);

        transactionPanel.add(transactionHeader, BorderLayout.NORTH);
        transactionPanel.add(scrollPane, BorderLayout.CENTER);

        JLabel footer = new JLabel(
                "POLO APPAREL  |  PRE-LOVED FASHION  |  UNIQUE FINDS"
        );
        footer.setFont(new Font("Arial", Font.PLAIN, 10));
        footer.setForeground(new Color(100, 85, 75));
        footer.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel topContent = new JPanel(new BorderLayout(0, 20));
        topContent.setBackground(cream);
        topContent.add(header, BorderLayout.NORTH);
        topContent.add(cards, BorderLayout.CENTER);

        content.add(topContent, BorderLayout.NORTH);
        content.add(transactionPanel, BorderLayout.CENTER);
        content.add(footer, BorderLayout.SOUTH);

        mainPanel.add(sidebar, BorderLayout.WEST);
        mainPanel.add(content, BorderLayout.CENTER);

        add(mainPanel);

        // BACK BUTTON
        btnBack.addActionListener(e -> {
            new WelcomePage().setVisible(true);
            dispose();
        });

        btnDashboard.addActionListener(e ->
                JOptionPane.showMessageDialog(
                        this, "You are already on the Dashboard."
                )
        );

        btnAdd.addActionListener(e -> {
            new NewItems().setVisible(true);
            dispose();
        });

        btnAvailable.addActionListener(e -> {
            new AvailableItems().setVisible(true);
            dispose();
        });

        btnNew.addActionListener(e -> {
            new NewItems().setVisible(true);
            dispose();
        });

        btnSold.addActionListener(e -> {
            new SoldThisWeek().setVisible(true);
            dispose();
        });

        btnTransactions.addActionListener(e -> {
            new TransactionHistory().setVisible(true);
            dispose();
        });

        viewAllButton.addActionListener(e -> {
            new TransactionHistory().setVisible(true);
            dispose();
        });

        btnLogout.addActionListener(e -> {
            int choice = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to log out?",
                    "Confirm Logout",
                    JOptionPane.YES_NO_OPTION
            );

            if (choice == JOptionPane.YES_OPTION) {
                new AdminLogin().setVisible(true);
                dispose();
            }
        });
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(200, 42));
        button.setPreferredSize(new Dimension(200, 42));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("Arial", Font.BOLD, 10));
        button.setForeground(cream);
        button.setBackground(burgundy);
        button.setFocusPainted(false);
        button.setBorder(
                BorderFactory.createEmptyBorder(10, 8, 10, 8)
        );
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private JPanel createCard(
            String title, String count, String description) {

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(white);
        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(220, 205, 180)
                        ),
                        BorderFactory.createEmptyBorder(15, 15, 15, 15)
                )
        );

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 11));
        titleLabel.setForeground(burgundy);

        JLabel countLabel = new JLabel(count);
        countLabel.setFont(new Font("Georgia", Font.BOLD, 30));
        countLabel.setForeground(black);

        JLabel descriptionLabel = new JLabel(description);
        descriptionLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        descriptionLabel.setForeground(new Color(110, 100, 90));

        card.add(titleLabel);
        card.add(Box.createVerticalStrut(8));
        card.add(countLabel);
        card.add(Box.createVerticalStrut(5));
        card.add(descriptionLabel);

        return card;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AdminDashBoard().setVisible(true);
        });
    }
}
