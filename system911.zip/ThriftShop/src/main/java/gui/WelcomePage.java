
package gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class WelcomePage extends JFrame {

    private final Color black = new Color(17, 17, 17);
    private final Color panel = new Color(27, 27, 27);
    private final Color burgundy = new Color(91, 15, 35);
    private final Color gold = new Color(207, 169, 97);
    private final Color cream = new Color(246, 239, 224);
    private final Color muted = new Color(175, 175, 175);

    public WelcomePage() {
        setTitle("POLO APPAREL | Thrift Sales and Inventory System");
        setSize(1200, 760);
        setMinimumSize(new Dimension(1000, 650));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(black);
        setContentPane(root);

        // TOP NAVIGATION
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(black);
        header.setBorder(new EmptyBorder(25, 45, 25, 45));

        JLabel logo = new JLabel("POLO APPAREL");
        logo.setFont(new Font("Serif", Font.BOLD, 25));
        logo.setForeground(gold);

        JLabel adminLabel = new JLabel("THRIFT SALES AND INVENTORY SYSTEM");
        adminLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        adminLabel.setForeground(cream);

        JPanel brand = new JPanel();
        brand.setLayout(new BoxLayout(brand, BoxLayout.Y_AXIS));
        brand.setBackground(black);
        brand.add(logo);
        brand.add(Box.createVerticalStrut(5));
        brand.add(adminLabel);

        JLabel access = new JLabel("ADMIN PORTAL");
        access.setFont(new Font("SansSerif", Font.BOLD, 12));
        access.setForeground(gold);

        header.add(brand, BorderLayout.WEST);
        header.add(access, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        // MAIN CONTENT
        JPanel content = new JPanel(new GridLayout(1, 2, 35, 0));
        content.setBackground(black);
        content.setBorder(new EmptyBorder(55, 65, 55, 65));

        // LEFT SIDE
        JPanel hero = new JPanel();
        hero.setLayout(new BoxLayout(hero, BoxLayout.Y_AXIS));
        hero.setBackground(black);

        JLabel eyebrow = new JLabel("WELCOME TO YOUR STORE");
        eyebrow.setFont(new Font("SansSerif", Font.BOLD, 12));
        eyebrow.setForeground(gold);

        JLabel title1 = new JLabel("Manage Your");
        title1.setFont(new Font("Serif", Font.BOLD, 48));
        title1.setForeground(cream);

        JLabel title2 = new JLabel("Thrift Business.");
        title2.setFont(new Font("Serif", Font.BOLD, 45));
        title2.setForeground(gold);

        JLabel description = new JLabel(
            "<html>Manage your clothing inventory, record sales,<br>"
            + "track transactions, and monitor your monthly<br>"
            + "income in one convenient system.</html>"
        );
        description.setFont(new Font("SansSerif", Font.PLAIN, 15));
        description.setForeground(muted);

        JButton startButton = new JButton("GET STARTED   →");
        startButton.setFont(new Font("SansSerif", Font.BOLD, 13));
        startButton.setForeground(cream);
        startButton.setBackground(burgundy);
        startButton.setFocusPainted(false);
        startButton.setBorderPainted(false);
        startButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        startButton.setPreferredSize(new Dimension(210, 48));
        startButton.setMaximumSize(new Dimension(210, 48));
        startButton.setAlignmentX(Component.LEFT_ALIGNMENT);

        startButton.addActionListener(e -> {
            new AdminLogin().setVisible(true);
            dispose();
        });

        hero.add(Box.createVerticalStrut(35));
        hero.add(eyebrow);
        hero.add(Box.createVerticalStrut(25));
        hero.add(title1);
        hero.add(Box.createVerticalStrut(3));
        hero.add(title2);
        hero.add(Box.createVerticalStrut(25));
        hero.add(description);
        hero.add(Box.createVerticalStrut(35));
        hero.add(startButton);

        // RIGHT SIDE FEATURE PANEL
        JPanel features = new JPanel();
        features.setLayout(new BoxLayout(features, BoxLayout.Y_AXIS));
        features.setBackground(panel);
        features.setBorder(new EmptyBorder(30, 30, 30, 30));

        JLabel featureHeading = new JLabel("YOUR STORE AT A GLANCE");
        featureHeading.setFont(new Font("SansSerif", Font.BOLD, 14));
        featureHeading.setForeground(gold);
        featureHeading.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel featureSubheading = new JLabel("Everything organized in one place.");
        featureSubheading.setFont(new Font("SansSerif", Font.PLAIN, 12));
        featureSubheading.setForeground(muted);
        featureSubheading.setAlignmentX(Component.LEFT_ALIGNMENT);

        features.add(featureHeading);
        features.add(Box.createVerticalStrut(8));
        features.add(featureSubheading);
        features.add(Box.createVerticalStrut(30));

        features.add(createFeature("01", "AVAILABLE ITEMS",
                "View and manage your clothing inventory."));
        features.add(createDivider());
        features.add(createFeature("02", "SOLD ITEMS",
                "Keep track of products already sold."));
        features.add(createDivider());
        features.add(createFeature("03", "TRANSACTIONS",
                "Review your store's sales records."));
        features.add(createDivider());
        features.add(createFeature("04", "MONTHLY INCOME",
                "Monitor your recorded sales income."));

        content.add(hero);
        content.add(features);
        root.add(content, BorderLayout.CENTER);

        // FOOTER
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(black);
        footer.setBorder(new EmptyBorder(18, 45, 22, 45));

        JLabel copyright = new JLabel("POLO APPAREL  ©  2026");
        copyright.setFont(new Font("SansSerif", Font.PLAIN, 11));
        copyright.setForeground(muted);

        JLabel tagline = new JLabel("CLASSIC STYLE  |  SMART MANAGEMENT");
        tagline.setFont(new Font("SansSerif", Font.PLAIN, 11));
        tagline.setForeground(gold);

        footer.add(copyright, BorderLayout.WEST);
        footer.add(tagline, BorderLayout.EAST);
        root.add(footer, BorderLayout.SOUTH);
    }

    private JPanel createFeature(String number, String title, String description) {
        JPanel item = new JPanel(new BorderLayout(15, 5));
        item.setBackground(panel);
        item.setBorder(new EmptyBorder(15, 0, 15, 0));
        item.setAlignmentX(Component.LEFT_ALIGNMENT);
        item.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));

        JLabel numberLabel = new JLabel(number);
        numberLabel.setFont(new Font("Serif", Font.BOLD, 23));
        numberLabel.setForeground(gold);
        numberLabel.setPreferredSize(new Dimension(45, 35));

        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setBackground(panel);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 13));
        titleLabel.setForeground(cream);

        JLabel descriptionLabel = new JLabel(
                "<html>" + description + "</html>");
        descriptionLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        descriptionLabel.setForeground(muted);

        textPanel.add(titleLabel);
        textPanel.add(Box.createVerticalStrut(7));
        textPanel.add(descriptionLabel);

        item.add(numberLabel, BorderLayout.WEST);
        item.add(textPanel, BorderLayout.CENTER);

        return item;
    }

    private JPanel createDivider() {
        JPanel divider = new JPanel();
        divider.setBackground(new Color(65, 65, 65));
        divider.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        divider.setPreferredSize(new Dimension(1, 1));
        return divider;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new WelcomePage().setVisible(true);
        });
    }
}
