
package gui;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;

public class AvailableItems extends JFrame {

    private final Color black = new Color(17, 17, 17);
    private final Color panel = new Color(28, 28, 28);
    private final Color burgundy = new Color(91, 15, 35);
    private final Color gold = new Color(207, 169, 97);
    private final Color cream = new Color(246, 239, 224);
    private final Color muted = new Color(165, 165, 165);

    private JTable table;
    private DefaultTableModel model;
    private JTextField searchField;

    public AvailableItems() {
        setTitle("POLO APPAREL | Available Items");
        setSize(1150, 700);
        setMinimumSize(new Dimension(950, 600));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(black);
        setContentPane(root);

        // HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(black);
        header.setBorder(new EmptyBorder(22, 30, 22, 30));

        JPanel leftHeader = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 15, 0)
        );
        leftHeader.setBackground(black);

        JButton backButton = createButton(
            "← BACK TO DASHBOARD", burgundy
        );
        backButton.setPreferredSize(new Dimension(190, 42));

        backButton.addActionListener(e -> {
            dispose();
            new AdminDashBoard().setVisible(true);
        });

        JLabel logo = new JLabel("POLO APPAREL");
        logo.setFont(new Font("Serif", Font.BOLD, 25));
        logo.setForeground(gold);

        leftHeader.add(backButton);
        leftHeader.add(logo);

        JLabel admin = new JLabel("ADMIN INVENTORY");
        admin.setFont(new Font("SansSerif", Font.BOLD, 11));
        admin.setForeground(cream);

        header.add(leftHeader, BorderLayout.WEST);
        header.add(admin, BorderLayout.EAST);

        root.add(header, BorderLayout.NORTH);

        // MAIN AREA
        JPanel main = new JPanel(new BorderLayout(0, 20));
        main.setBackground(black);
        main.setBorder(new EmptyBorder(10, 30, 25, 30));

        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(
            new BoxLayout(titlePanel, BoxLayout.Y_AXIS)
        );
        titlePanel.setBackground(black);

        JLabel title = new JLabel("Available Items");
        title.setFont(new Font("Serif", Font.BOLD, 34));
        title.setForeground(cream);

        JLabel subtitle = new JLabel(
            "Manage your clothing inventory and item details."
        );
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        subtitle.setForeground(muted);

        titlePanel.add(title);
        titlePanel.add(Box.createVerticalStrut(7));
        titlePanel.add(subtitle);

        main.add(titlePanel, BorderLayout.NORTH);

        // TABLE AND SEARCH PANEL
        JPanel center = new JPanel(new BorderLayout(0, 15));
        center.setBackground(black);

        JPanel toolbar = new JPanel(new BorderLayout(10, 0));
        toolbar.setBackground(black);

        searchField = new JTextField();
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 13));
        searchField.setBackground(panel);
        searchField.setForeground(cream);
        searchField.setCaretColor(gold);
        searchField.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    new Color(70, 70, 70)
                ),
                new EmptyBorder(10, 12, 10, 12)
            )
        );
        searchField.setPreferredSize(new Dimension(250, 42));

        JButton searchButton = createButton("SEARCH", burgundy);
        JButton refreshButton = createButton("REFRESH", panel);
        JButton addButton = createButton("+ ADD ITEM", burgundy);

        JPanel searchActions = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 8, 0)
        );
        searchActions.setBackground(black);
        searchActions.add(searchField);
        searchActions.add(searchButton);
        searchActions.add(refreshButton);

        toolbar.add(searchActions, BorderLayout.WEST);
        toolbar.add(addButton, BorderLayout.EAST);

        center.add(toolbar, BorderLayout.NORTH);

        // TABLE
        String[] columns = {
            "ID", "ITEM NAME", "CATEGORY", "SIZE",
            "PRICE", "QUANTITY", "CONDITION", "DATE ADDED"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setFont(new Font("SansSerif", Font.PLAIN, 12));
        table.setRowHeight(38);
        table.setBackground(panel);
        table.setForeground(cream);
        table.setGridColor(new Color(55, 55, 55));
        table.setSelectionBackground(burgundy);
        table.setSelectionForeground(cream);
        table.setShowVerticalLines(false);
        table.setFillsViewportHeight(true);
        table.setAutoCreateRowSorter(true);

        table.getTableHeader().setFont(
            new Font("SansSerif", Font.BOLD, 11)
        );
        table.getTableHeader().setBackground(burgundy);
        table.getTableHeader().setForeground(cream);
        table.getTableHeader().setPreferredSize(
            new Dimension(100, 40)
        );
        table.getTableHeader().setReorderingAllowed(false);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setBackground(panel);
        scrollPane.setBorder(
            BorderFactory.createLineBorder(
                new Color(65, 65, 65)
            )
        );

        center.add(scrollPane, BorderLayout.CENTER);
        main.add(center, BorderLayout.CENTER);

        // FOOTER BUTTONS
        JPanel footer = new JPanel(
            new FlowLayout(FlowLayout.RIGHT, 10, 0)
        );
        footer.setBackground(black);

        JButton soldButton = createButton("MARK AS SOLD", burgundy);
        JButton closeButton = createButton("CLOSE", panel);

        footer.add(soldButton);
        footer.add(closeButton);

        main.add(footer, BorderLayout.SOUTH);
        root.add(main, BorderLayout.CENTER);

        // BUTTON ACTIONS
        searchButton.addActionListener(e -> searchItems());
        searchField.addActionListener(e -> searchItems());

        refreshButton.addActionListener(e -> {
            searchField.setText("");
            loadItems();
        });

        addButton.addActionListener(e -> openAddItemDialog());
        soldButton.addActionListener(e -> markAsSold());
        closeButton.addActionListener(e -> dispose());

        loadItems();
    }

    private JButton createButton(String text, Color background) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 11));
        button.setForeground(cream);
        button.setBackground(background);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(125, 42));
        return button;
    }

    // LOAD AVAILABLE ITEMS
    private void loadItems() {
        model.setRowCount(0);

        String sql = "SELECT item_id, item_name, category, size, price, "
                   + "quantity, item_condition, date_added "
                   + "FROM items WHERE status = 'AVAILABLE' "
                   + "ORDER BY item_id DESC";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("item_id"),
                    rs.getString("item_name"),
                    rs.getString("category"),
                    rs.getString("size"),
                    rs.getBigDecimal("price"),
                    rs.getInt("quantity"),
                    rs.getString("item_condition"),
                    rs.getDate("date_added")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                this,
                "Could not load items.\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // SEARCH ITEMS
    private void searchItems() {
        String keyword = searchField.getText().trim();
        model.setRowCount(0);

        String sql = "SELECT item_id, item_name, category, size, price, "
                   + "quantity, item_condition, date_added "
                   + "FROM items "
                   + "WHERE status = 'AVAILABLE' "
                   + "AND (item_name LIKE ? OR category LIKE ? "
                   + "OR size LIKE ?) ORDER BY item_id DESC";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            String search = "%" + keyword + "%";
            ps.setString(1, search);
            ps.setString(2, search);
            ps.setString(3, search);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("item_id"),
                        rs.getString("item_name"),
                        rs.getString("category"),
                        rs.getString("size"),
                        rs.getBigDecimal("price"),
                        rs.getInt("quantity"),
                        rs.getString("item_condition"),
                        rs.getDate("date_added")
                    });
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                this,
                "Search failed.\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ADD NEW ITEM
    private void openAddItemDialog() {
        JTextField nameField = new JTextField();
        JTextField categoryField = new JTextField();
        JTextField sizeField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField quantityField = new JTextField("1");

        String[] conditions = {
            "Pre-Owned", "Like New", "Brand New"
        };

        JComboBox<String> conditionBox =
            new JComboBox<>(conditions);

        JPanel form = new JPanel(new GridLayout(0, 2, 10, 10));

        form.add(new JLabel("Item Name:"));
        form.add(nameField);
        form.add(new JLabel("Category:"));
        form.add(categoryField);
        form.add(new JLabel("Size:"));
        form.add(sizeField);
        form.add(new JLabel("Price (PHP):"));
        form.add(priceField);
        form.add(new JLabel("Quantity:"));
        form.add(quantityField);
        form.add(new JLabel("Condition:"));
        form.add(conditionBox);

        int result = JOptionPane.showConfirmDialog(
            this,
            form,
            "Add New Item",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        String name = nameField.getText().trim();
        String category = categoryField.getText().trim();
        String size = sizeField.getText().trim();
        String priceText = priceField.getText().trim();
        String quantityText = quantityField.getText().trim();

        if (name.isEmpty() || category.isEmpty() || size.isEmpty()
                || priceText.isEmpty() || quantityText.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Please fill in all fields.",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        try {
            java.math.BigDecimal price =
                new java.math.BigDecimal(priceText);

            int quantity = Integer.parseInt(quantityText);

            if (price.compareTo(java.math.BigDecimal.ZERO) <= 0
                    || quantity <= 0) {
                JOptionPane.showMessageDialog(
                    this,
                    "Price and quantity must be greater than zero.",
                    "Validation Error",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            String sql = "INSERT INTO items "
                + "(item_name, category, size, price, quantity, "
                + "item_condition, date_added, status) "
                + "VALUES (?, ?, ?, ?, ?, ?, CURRENT_DATE, 'AVAILABLE')";

            try (Connection con = DatabaseConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, name);
                ps.setString(2, category);
                ps.setString(3, size);
                ps.setBigDecimal(4, price);
                ps.setInt(5, quantity);
                ps.setString(
                    6, (String) conditionBox.getSelectedItem()
                );

                ps.executeUpdate();

                JOptionPane.showMessageDialog(
                    this,
                    "Item added successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
                );

                loadItems();
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                this,
                "Enter a valid number for price and quantity.",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE
            );
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                this,
                "Could not add item.\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // MARK ITEM AS SOLD
    private void markAsSold() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                this,
                "Please select an item first.",
                "No Item Selected",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int modelRow = table.convertRowIndexToModel(selectedRow);

        int itemId = Integer.parseInt(
            model.getValueAt(modelRow, 0).toString()
        );

        int quantityAvailable = Integer.parseInt(
            model.getValueAt(modelRow, 5).toString()
        );

        String quantityText = JOptionPane.showInputDialog(
            this,
            "Quantity to sell (available: "
                + quantityAvailable + "):",
            "1"
        );

        if (quantityText == null) {
            return;
        }

        try {
            int quantityToSell =
                Integer.parseInt(quantityText.trim());

            if (quantityToSell <= 0
                    || quantityToSell > quantityAvailable) {
                JOptionPane.showMessageDialog(
                    this,
                    "Enter a quantity from 1 to "
                        + quantityAvailable + ".",
                    "Invalid Quantity",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            String customerName = JOptionPane.showInputDialog(
                this, "Enter customer name:"
            );

            if (customerName == null) {
                return;
            }

            customerName = customerName.trim();

            if (customerName.isEmpty()) {
                JOptionPane.showMessageDialog(
                    this,
                    "Customer name is required.",
                    "Validation Error",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            java.math.BigDecimal unitPrice =
                new java.math.BigDecimal(
                    model.getValueAt(modelRow, 4).toString()
                );

            java.math.BigDecimal total = unitPrice.multiply(
                java.math.BigDecimal.valueOf(quantityToSell)
            );

            int confirm = JOptionPane.showConfirmDialog(
                this,
                "Customer: " + customerName
                    + "\nQuantity: " + quantityToSell
                    + "\nTotal: PHP " + total
                    + "\n\nConfirm sale?",
                "Confirm Sale",
                JOptionPane.YES_NO_OPTION
            );

            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            try (Connection con = DatabaseConnection.getConnection()) {
                con.setAutoCommit(false);

                try {
                    String insertSql = "INSERT INTO transactions "
                        + "(customer_name, item_id, quantity_sold, "
                        + "sold_price, total_amount) "
                        + "VALUES (?, ?, ?, ?, ?)";

                    try (PreparedStatement ps =
                            con.prepareStatement(insertSql)) {
                        ps.setString(1, customerName);
                        ps.setInt(2, itemId);
                        ps.setInt(3, quantityToSell);
                        ps.setBigDecimal(4, unitPrice);
                        ps.setBigDecimal(5, total);
                        ps.executeUpdate();
                    }

                    String updateSql;

                    if (quantityToSell == quantityAvailable) {
                        updateSql = "UPDATE items SET quantity = 0, "
                                  + "status = 'SOLD' WHERE item_id = ?";
                    } else {
                        updateSql = "UPDATE items "
                                  + "SET quantity = quantity - ? "
                                  + "WHERE item_id = ?";
                    }

                    try (PreparedStatement ps =
                            con.prepareStatement(updateSql)) {

                        if (quantityToSell == quantityAvailable) {
                            ps.setInt(1, itemId);
                        } else {
                            ps.setInt(1, quantityToSell);
                            ps.setInt(2, itemId);
                        }

                        ps.executeUpdate();
                    }

                    con.commit();

                    JOptionPane.showMessageDialog(
                        this,
                        "Sale recorded successfully!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE
                    );

                } catch (SQLException e) {
                    con.rollback();
                    throw e;
                } finally {
                    con.setAutoCommit(true);
                }
            }

            loadItems();

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                this,
                "Please enter a valid whole number for quantity.",
                "Validation Error",
                JOptionPane.WARNING_MESSAGE
            );
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                this,
                "Could not record sale.\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
            new AvailableItems().setVisible(true)
        );
    }
}
