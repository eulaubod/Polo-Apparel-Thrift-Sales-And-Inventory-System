
package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.text.NumberFormat;
import java.util.Locale;

public class TransactionHistory extends JFrame {

    private final Color BLACK = new Color(18, 18, 18);
    private final Color BURGUNDY = new Color(92, 20, 43);
    private final Color GOLD = new Color(205, 170, 95);
    private final Color CREAM = new Color(248, 244, 235);
    private final Color GRAY = new Color(225, 221, 213);

    private JTable table;
    private DefaultTableModel model;
    private JTextField searchField;
    private JLabel totalSalesLabel;
    private JLabel transactionCountLabel;

    private final NumberFormat money =
            NumberFormat.getCurrencyInstance(new Locale("en", "PH"));

    public TransactionHistory() {
        setTitle("POLO APPAREL | Transaction History");
        setSize(1150, 700);
        setMinimumSize(new Dimension(950, 600));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(CREAM);
        setLayout(new BorderLayout());

        add(createHeader(), BorderLayout.NORTH);
        add(createMainPanel(), BorderLayout.CENTER);

        loadTransactions("");
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BLACK);
        header.setBorder(BorderFactory.createEmptyBorder(22, 30, 22, 30));

        JPanel brandPanel = new JPanel();
        brandPanel.setLayout(new BoxLayout(brandPanel, BoxLayout.Y_AXIS));
        brandPanel.setOpaque(false);

        JLabel brand = new JLabel("POLO APPAREL");
        brand.setFont(new Font("Serif", Font.BOLD, 27));
        brand.setForeground(GOLD);

        JLabel subtitle = new JLabel("THRIFT MANAGEMENT SYSTEM");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 11));
        subtitle.setForeground(CREAM);

        brandPanel.add(brand);
        brandPanel.add(Box.createVerticalStrut(5));
        brandPanel.add(subtitle);

        JPanel headerButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        headerButtons.setOpaque(false);

        JButton backButton = createButton("BACK", BURGUNDY);
        JButton refreshButton = createButton("REFRESH", BURGUNDY);

        backButton.addActionListener(e -> {
            new AdminDashBoard().setVisible(true);
            dispose();
        });

        refreshButton.addActionListener(e ->
                loadTransactions(searchField.getText().trim()));

        headerButtons.add(backButton);
        headerButtons.add(refreshButton);

        header.add(brandPanel, BorderLayout.WEST);
        header.add(headerButtons, BorderLayout.EAST);

        return header;
    }

    private JPanel createMainPanel() {
        JPanel main = new JPanel(new BorderLayout(0, 20));
        main.setBackground(CREAM);
        main.setBorder(BorderFactory.createEmptyBorder(25, 30, 30, 30));

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setOpaque(false);

        JLabel title = new JLabel("Transaction History");
        title.setFont(new Font("Serif", Font.BOLD, 30));
        title.setForeground(BLACK);

        JLabel description = new JLabel(
                "Review customer purchases and completed sales.");
        description.setFont(new Font("SansSerif", Font.PLAIN, 13));
        description.setForeground(new Color(100, 95, 88));

        topPanel.add(title);
        topPanel.add(Box.createVerticalStrut(7));
        topPanel.add(description);
        topPanel.add(Box.createVerticalStrut(20));
        topPanel.add(createSummaryPanel());
        topPanel.add(Box.createVerticalStrut(20));
        topPanel.add(createSearchPanel());

        JPanel tablePanel = new JPanel(new BorderLayout(0, 12));
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(GRAY),
                BorderFactory.createEmptyBorder(18, 18, 18, 18)));

        JLabel tableTitle = new JLabel("ALL TRANSACTION RECORDS");
        tableTitle.setFont(new Font("SansSerif", Font.BOLD, 14));
        tableTitle.setForeground(BURGUNDY);

        model = new DefaultTableModel(
                new String[]{
                    "Transaction ID", "Customer Name", "Item Name",
                    "Quantity", "Selling Price", "Total Amount",
                    "Date and Time"
                }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setFont(new Font("SansSerif", Font.PLAIN, 12));
        table.setRowHeight(32);
        table.setBackground(Color.WHITE);
        table.setForeground(BLACK);
        table.setSelectionBackground(new Color(238, 225, 194));
        table.setSelectionForeground(BLACK);
        table.setGridColor(GRAY);
        table.setShowVerticalLines(false);

        table.getTableHeader().setFont(
                new Font("SansSerif", Font.BOLD, 11));
        table.getTableHeader().setBackground(BLACK);
        table.getTableHeader().setForeground(GOLD);
        table.getTableHeader().setPreferredSize(new Dimension(0, 38));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        tablePanel.add(tableTitle, BorderLayout.NORTH);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        main.add(topPanel, BorderLayout.NORTH);
        main.add(tablePanel, BorderLayout.CENTER);

        return main;
    }

    private JPanel createSummaryPanel() {
        JPanel summary = new JPanel(new GridLayout(1, 2, 15, 0));
        summary.setOpaque(false);

        totalSalesLabel = new JLabel("₱0.00");
        transactionCountLabel = new JLabel("0");

        summary.add(createSummaryCard("TOTAL SALES", totalSalesLabel));
        summary.add(createSummaryCard(
                "TOTAL TRANSACTIONS", transactionCountLabel));

        return summary;
    }

    private JPanel createSummaryCard(String title, JLabel value) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(GRAY),
                BorderFactory.createEmptyBorder(15, 18, 15, 18)));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 11));
        titleLabel.setForeground(new Color(100, 95, 88));

        value.setFont(new Font("Serif", Font.BOLD, 25));
        value.setForeground(BURGUNDY);

        card.add(titleLabel);
        card.add(Box.createVerticalStrut(10));
        card.add(value);

        return card;
    }

    private JPanel createSearchPanel() {
        JPanel searchPanel = new JPanel(new BorderLayout(10, 0));
        searchPanel.setOpaque(false);

        searchField = new JTextField();
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 13));
        searchField.setPreferredSize(new Dimension(250, 38));
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(GRAY),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));

        searchField.addActionListener(e ->
                loadTransactions(searchField.getText().trim()));

        JButton searchButton = createButton("SEARCH", BLACK);
        searchButton.addActionListener(e ->
                loadTransactions(searchField.getText().trim()));

        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchButton, BorderLayout.EAST);

        return searchPanel;
    }

    private JButton createButton(String text, Color background) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 12));
        button.setBackground(background);
        button.setForeground(CREAM);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(130, 38));
        return button;
    }

    private void loadTransactions(String keyword) {
        model.setRowCount(0);

        String sql =
                "SELECT t.transaction_id, t.customer_name, i.item_name, " +
                "t.quantity_sold, t.sold_price, t.total_amount, " +
                "t.transaction_date " +
                "FROM transactions t " +
                "JOIN items i ON t.item_id = i.item_id " +
                "WHERE CAST(t.transaction_id AS CHAR) LIKE ? " +
                "OR t.customer_name LIKE ? " +
                "OR i.item_name LIKE ? " +
                "ORDER BY t.transaction_date DESC";

        double totalSales = 0;
        int transactionCount = 0;
        String search = "%" + keyword + "%";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, search);
            ps.setString(2, search);
            ps.setString(3, search);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Timestamp date = rs.getTimestamp("transaction_date");

                    model.addRow(new Object[]{
                        rs.getInt("transaction_id"),
                        rs.getString("customer_name"),
                        rs.getString("item_name"),
                        rs.getInt("quantity_sold"),
                        money.format(rs.getBigDecimal("sold_price")),
                        money.format(rs.getBigDecimal("total_amount")),
                        date == null ? "" :
                                date.toLocalDateTime().toString()
                                        .replace('T', ' ')
                    });

                    totalSales += rs.getDouble("total_amount");
                    transactionCount++;
                }
            }

            totalSalesLabel.setText(money.format(totalSales));
            transactionCountLabel.setText(
                    String.valueOf(transactionCount));

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Could not load transaction history.\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
                new TransactionHistory().setVisible(true));
    }
}
