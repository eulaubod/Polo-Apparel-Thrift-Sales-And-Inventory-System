package main;

import gui.WelcomePage;

public class Main {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new WelcomePage().setVisible(true);
        });
    }
}